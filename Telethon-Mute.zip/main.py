from telethon import TelegramClient, events
from config import API_ID, API_HASH

client = TelegramClient("session", API_ID, API_HASH)
muted = set()

@client.on(events.NewMessage(incoming=True))
async def handler(event):
    if not event.is_private:
        return

    sender = await event.get_sender()

    if event.raw_text == "كتم":
        reply = await event.get_reply_message()
        if not reply:
            await event.reply("❌ يجب الرد على رسالة الشخص")
            return
        user = await reply.get_sender()
        muted.add(user.id)
        await event.reply("✅ تم الكتم")
        return

    if event.raw_text == "فك_الكتم":
        reply = await event.get_reply_message()
        if not reply:
            await event.reply("❌ يجب الرد على رسالة الشخص")
            return
        user = await reply.get_sender()
        muted.discard(user.id)
        await event.reply("✅ تم فك الكتم")
        return

    if sender.id in muted:
        await event.delete()

print("Userbot Started ✅")
client.start()
client.run_until_disconnected()
