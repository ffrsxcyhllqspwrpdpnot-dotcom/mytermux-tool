API_ID = 123456
API_HASH = "ضع_api_hash_هنا"
