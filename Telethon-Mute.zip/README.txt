عدل config.py ثم شغل: pip install -r requirements.txt ثم python3 main.py
